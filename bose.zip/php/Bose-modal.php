<div class="modal" id="myModal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form class="form-modal" action="">
            <label class="form-label" for="">
                <input class="form-input" type="text" placeholder="Your name">
            </label>
            <label class="form-label" for="">
                <input class="form-input" type=" email" placeholder="Your e-mail">
            </label>
            <label class="form-label" for="">
                <textarea class="form-input form-textarea" name="" id="" cols=" 30" rows="10" placeholder="Send us a message"></textarea>
            </label>

            <div class="checkbox-block">
                <div class="checkbox">
                    <input id="checkbox-nc" type="checkbox" checked>
                    <label for="checkbox-nc" class="black checkbox-label"></label>
                </div>
                <div class="checkbox">
                    <input id="checkbox-white" type="checkbox">
                    <label for="checkbox-white" class="checkbox-label"></label>
                </div>
            </div>

            <div class="bose-nc--number">399 USD</div>

            <button class="form-button" type="submit">ORDER</button>
        </form>
    </div>
</div>