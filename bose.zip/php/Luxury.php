<section class="luxury-container">
    <h2 class="luxury-title general-title">THE LUXURY OF SILENCE</h2>
    <div class="luxury-img"></div>
    <div class="luxury-two--img"></div>
</section>

<section class="container">
    <article class="luxury-article">
        <div class="luxury-block">
            <h3 class="general-title--small">Maximum enjoyment</h3>
            <p class="general-text">In order to create a comfortable atmosphere - raise the level by level from the "transparent" mode to the maximum blocking of sounds. The conversation mode can be activated in one click using a special button.</p>
        </div>
        <div>
            <h3 class="general-title--small">Crystal sound</h3>
            <p class="general-text">The speaker system and brand name active equalizer are able to provide high-quality and powerful sound at any volume level. You can be sure of no distortion and crystal clear at high and low frequencies.</p>
        </div>
    </article>
</section>