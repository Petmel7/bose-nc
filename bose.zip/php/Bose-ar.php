<section class="container">
    <div class="bose-ar--block">
        <article>
            <h2 class="general-title">BOSE AR</h2>
            <h3 class="general-title--small">Brand name technology</h3>
            <p class="bose-ar-text general-text">Bose AR is a unique audio platform augmented reality, that opens before you new facets of sound. It allows you to stay connected to the real world and immerse yourself in the virtual universe at the same time.</p>
        </article>
        <div class="bose-img"></div>
    </div>
</section>