<section class="container">
    <div class="capable">
        <h2 class="capable-title general-title">CAPABLE OF SO MUCH</h2>
        <div class="capable-block">
            <ul class="capable-list">
                <li>Ability to receive calls</li>
                <li>Rich and powerful sound</li>
                <li>Active noise cancellation option</li>
            </ul>
            <ul class="capable-list">
                <li>Unsurpassed microphone system</li>
                <li>Support of voice assistants</li>
                <li>Bose AR Augmented Reality Audio Platform</li>
            </ul>
        </div>
    </div>
</section>