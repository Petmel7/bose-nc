<section class="container">
    <div class="guarantees">
        <article>
            <h2 class="general-title">GUARANTEES</h2>
            <h3 class="general-title--small">90 Day Money Back Guarantee</h3>
            <p class="general-text">If you are not 100% satisfied with a product, you can return it back for a full refund.</p>
            <h3 class="general-title--small">1 year warranty</h3>
            <p class="general-text">Regardless of your country of residence, if your headphones are broken, we will send you new ones.</p>
        </article>
        <div class="guarantees-img"></div>
    </div>
</section>