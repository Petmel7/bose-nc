function redirectTosigninPage() {
    window.location.href = 'index.php?page=signin';
}
