
function toggleMenu() {
    let menu = document.querySelector('.menu');
    let burger = document.querySelector('.burger');

    menu.classList.toggle('active');
    burger.classList.toggle('active');
}