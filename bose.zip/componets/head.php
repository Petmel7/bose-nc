<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>bose</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="styles/Hero-header.css">
    <link rel="stylesheet" href="styles/Design.css">
    <link rel="stylesheet" href="styles/Capable.css">
    <link rel="stylesheet" href="styles/Luxury.css">
    <link rel="stylesheet" href="styles/Bose-ar.css">
    <link rel="stylesheet" href="styles/Guarantees.css">
    <link rel="stylesheet" href="styles/Brand.css">
    <link rel="stylesheet" href="styles/Reviews.css">
    <link rel="stylesheet" href="styles/FAQ.css">
    <link rel="stylesheet" href="styles/Bose-nc.css">
    <link rel="stylesheet" href="styles/Footer.css">
    <link rel="stylesheet" href="styles/bose-modal.css">
    <link rel="stylesheet" href="styles/comments.css">
</head>